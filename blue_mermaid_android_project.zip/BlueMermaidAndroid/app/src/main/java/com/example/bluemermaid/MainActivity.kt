package com.example.bluemermaid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("pet_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 38, 32, 28)
            setBackgroundColor(0xFFF4F7FF.toInt())
        }
        val title = TextView(this).apply {
            text = "蓝尾桌宠"
            textSize = 30f
            setTextColor(0xFF244477.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "让蓝发人鱼少女陪你使用手机"
            textSize = 15f
            setTextColor(0xFF596A86.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(makeButton("① 授予悬浮窗权限") { requestOverlayPermission() })
        root.addView(makeButton("② 启动桌宠") { startPet() })
        root.addView(makeButton("停止桌宠") { stopService(Intent(this, PetOverlayService::class.java)); toast("已发送停止指令") })
        root.addView(makeButton("互动玩法与使用说明") { showHelp() })
        val auto = Switch(this).apply {
            text = "开机后尝试自动启动桌宠"
            textSize = 16f
            setTextColor(0xFF244477.toInt())
            isChecked = prefs.getBoolean("autostart", false)
            setPadding(4, 22, 4, 22)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("autostart", checked).apply()
                toast(if (checked) "已开启；部分品牌手机还需允许自启动/后台运行" else "已关闭开机启动")
            }
        }
        root.addView(auto)
        val note = TextView(this).apply {
            text = "说明：悬浮在其他应用上方需要系统授权。不同手机的后台策略不同；如果桌宠被系统清理，请在系统设置中允许后台运行。"
            textSize = 13f
            setTextColor(0xFF65718A.toInt())
            setPadding(0, 18, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = 10
            layoutParams = lp
        }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            toast("悬浮窗权限已开启")
            return
        }
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun startPet() {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("需要悬浮窗权限")
                .setMessage("请先允许“蓝尾桌宠”显示在其他应用上层。")
                .setPositiveButton("去设置") { _, _ -> requestOverlayPermission() }
                .setNegativeButton("取消", null).show()
            return
        }
        val intent = Intent(this, PetOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        toast("桌宠启动指令已发送")
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("桌宠玩法")
            .setMessage("点击角色：随机回应\n双击角色：特别反应\n拖动角色：移动位置\n双指捏合：缩放（部分设备支持）\n点角色旁的菜单按钮：打开 30+ 项玩法\n\n菜单包括：摸头、夸奖、讲笑话、猜拳、跳舞、睡觉、冥想、心情、喂食、拍照式闪光、弹跳、旋转、翻转、透明度、大小、位置、隐藏菜单、跟随/漫步等。\n\n开机启动受 Android 和手机厂商限制，首次使用需先手动启动并授权。")
            .setPositiveButton("知道了", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
