package com.example.bluemermaid

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("pet_settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("autostart", false) || !Settings.canDrawOverlays(context)) return
        // Android may restrict background starts; OEM auto-start permission may also be required.
        val launch = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(launch)
        } catch (_: Exception) {
            // Fail safely; user can launch the app manually.
        }
    }
}
