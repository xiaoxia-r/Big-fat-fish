package com.example.bluemermaid

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class PetOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var image: ImageView
    private lateinit var bubble: TextView
    private lateinit var menuPanel: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var menuParams: WindowManager.LayoutParams
    private val prefs by lazy { getSharedPreferences("pet_settings", MODE_PRIVATE) }
    private var petSize = 220
    private var alphaValue = 1f
    private var flipped = false
    private var tapCount = 0
    private var lastTap = 0L
    private var menuShown = false
    private var followMode = false
    private var idleMode = true
    private val menuItems = listOf(
        "摸摸头" to "嘿嘿，好舒服！",
        "夸夸她" to "今天也要一起加油！",
        "讲个冷笑话" to "为什么鱼不爱上网？因为怕掉进鱼缸网！",
        "猜拳" to listOf("石头！", "剪刀！", "布！").random(),
        "跳舞" to "♪ 跟着节奏摇摆 ♪",
        "睡觉" to "Zzz……我先眯一会儿。",
        "叫醒" to "我醒啦！",
        "冥想" to "吸气……呼气……",
        "喂食" to "谢谢投喂！好吃！",
        "送爱心" to "♡♡♡ 收到你的心意啦！",
        "鼓励一下" to "再坚持一下，你可以的！",
        "随机心情" to listOf("开心！", "有一点困……", "今天超有精神！", "想去海里游泳！").random(),
        "闪闪特效" to "✨ 闪亮登场！",
        "弹跳一下" to "咚！",
        "旋转一下" to "转圈圈！",
        "翻转角色" to "换个方向看世界。",
        "变大" to "看我变大！",
        "变小" to "迷你人鱼上线。",
        "恢复大小" to "恢复默认尺寸。",
        "更透明" to "我变得轻盈了一点。",
        "恢复不透明" to "我回来啦！",
        "移动到左侧" to "我去左边啦。",
        "移动到右侧" to "我去右边啦。",
        "移动到屏幕中间" to "这里视野不错！",
        "靠近底部" to "在下面陪你。",
        "跟随模式" to "跟随模式切换。",
        "自动漫步" to "我去附近逛逛。",
        "停止漫步" to "好，我待在这里。",
        "切换置顶" to "置顶状态已切换。",
        "显示/隐藏菜单" to "菜单已切换。",
        "休息提醒" to "记得起来活动一下眼睛和身体。",
        "点击计数" to "你已经点我 $tapCount 次啦！"
    )

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        petSize = prefs.getInt("size", 220).coerceIn(100, 420)
        alphaValue = prefs.getFloat("alpha", 1f).coerceIn(0.25f, 1f)
        createNotification()
        buildOverlay()
    }

    private fun createNotification() {
        val channelId = "blue_mermaid_pet"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "蓝尾桌宠", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("蓝尾桌宠正在运行")
                .setContentText("点击角色互动；点旁边的小圆按钮打开玩法菜单")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("蓝尾桌宠正在运行")
                .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
        }
        startForeground(41, notification)
    }

    private fun buildOverlay() {
        val density = resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        bubble = TextView(this).apply {
            text = "你好呀！点点我试试～"
            textSize = 13f
            setTextColor(Color.rgb(39, 58, 94))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = GradientDrawable().apply {
                setColor(0xF2FFFFFF.toInt())
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0xFF9CB9E8.toInt())
            }
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        root.addView(bubble, LinearLayout.LayoutParams(dp(petSize + 36), LinearLayout.LayoutParams.WRAP_CONTENT))
        val stage = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        image = ImageView(this).apply {
            setImageResource(R.drawable.pet)
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = alphaValue
            contentDescription = "蓝发人鱼桌宠"
            setOnTouchListener { _, event -> handlePetTouch(event) }
            setOnClickListener { reactToTap() }
        }
        stage.addView(image, LinearLayout.LayoutParams(dp(petSize), dp((petSize * 1.45f).toInt())))
        val menuButton = TextView(this).apply {
            text = "⋯"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF456BB0.toInt())
            }
            setOnClickListener { toggleMenu() }
        }
        stage.addView(menuButton, LinearLayout.LayoutParams(dp(38), dp(38)))
        root.addView(stage)
        params = WindowManager.LayoutParams(
            dp(petSize + 55), dp((petSize * 1.45f).toInt() + dp(70)),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", resources.displayMetrics.widthPixels - dp(petSize + 60)).coerceAtLeast(0)
            y = prefs.getInt("y", dp(120)).coerceAtLeast(0)
        }
        try { wm.addView(root, params) } catch (_: Exception) { stopSelf(); return }
        buildMenu(dp)
        startIdleAnimation()
    }

    private fun buildMenu(dp: (Int) -> Int) {
        menuPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xF7FFFFFF.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFF8CAFE5.toInt())
            }
            visibility = View.GONE
        }
        val heading = TextView(this).apply {
            text = "人鱼互动菜单 · 32 项"
            textSize = 16f
            setTextColor(0xFF244477.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        menuPanel.addView(heading)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        menuItems.forEachIndexed { index, item ->
            val b = Button(this).apply {
                text = "${index + 1}. ${item.first}"
                textSize = 13f
                isAllCaps = false
                setOnClickListener { performAction(index, item.first, item.second) }
            }
            list.addView(b, LinearLayout.LayoutParams(-1, dp(42)))
        }
        scroll.addView(list)
        menuPanel.addView(scroll, LinearLayout.LayoutParams(dp(220), dp(330)))
        menuParams = WindowManager.LayoutParams(
            dp(240), dp(390),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(120) }
        try { wm.addView(menuPanel, menuParams) } catch (_: Exception) {}
    }

    private fun handlePetTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = e.rawX
                touchStartY = e.rawY
                startWindowX = params.x
                startWindowY = params.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - touchStartX).toInt()
                val dy = (e.rawY - touchStartY).toInt()
                if (abs(dx) > 5 || abs(dy) > 5) moved = true
                if (moved) {
                    params.x = (startWindowX + dx).coerceAtLeast(0)
                    params.y = (startWindowY + dy).coerceAtLeast(0)
                    try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                    if (menuShown) repositionMenu()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (moved) {
                    prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
                } else {
                    val now = System.currentTimeMillis()
                    tapCount++
                    if (now - lastTap < 350) {
                        bubble.text = "双击捕捉成功！✨"
                        bounce()
                    } else {
                        bubble.text = listOf("嗯？你叫我吗？", "今天也要加油呀！", "尾巴摇摇～", "陪你一会儿！").random()
                    }
                    bubble.visibility = View.VISIBLE
                    lastTap = now
                    bubble.postDelayed({ if (bubble.visibility == View.VISIBLE) bubble.visibility = View.GONE }, 2200)
                    image.performClick()
                }
                return true
            }
        }
        return false
    }

    private var touchStartX = 0f
    private var touchStartY = 0f
    private var startWindowX = 0
    private var startWindowY = 0
    private var moved = false

    private fun reactToTap() {
        bubble.visibility = View.VISIBLE
        bubble.text = listOf("啵！", "摸摸头吗？", "人鱼收到！", "今天心情不错～").random()
        bounce()
        bubble.postDelayed({ bubble.visibility = View.GONE }, 2200)
    }

    private fun toggleMenu() {
        menuShown = !menuShown
        menuPanel.visibility = if (menuShown) View.VISIBLE else View.GONE
        repositionMenu()
    }

    private fun repositionMenu() {
        val sw = resources.displayMetrics.widthPixels
        menuParams.x = if (params.x > sw / 2) max(0, params.x - menuParams.width) else min(sw - menuParams.width, params.x + params.width)
        menuParams.y = params.y.coerceAtLeast(0)
        try { wm.updateViewLayout(menuPanel, menuParams) } catch (_: Exception) {}
    }

    private fun performAction(index: Int, label: String, response: String) {
        when (index) {
            15 -> { flipped = !flipped; image.scaleX = if (flipped) -1f else 1f }
            16 -> resize(petSize + 35)
            17 -> resize(petSize - 30)
            18 -> resize(220)
            19 -> { alphaValue = (alphaValue - 0.18f).coerceAtLeast(0.25f); image.alpha = alphaValue; prefs.edit().putFloat("alpha", alphaValue).apply() }
            20 -> { alphaValue = 1f; image.alpha = 1f; prefs.edit().putFloat("alpha", alphaValue).apply() }
            21 -> { params.x = 0; updatePosition() }
            22 -> { params.x = (resources.displayMetrics.widthPixels - params.width).coerceAtLeast(0); updatePosition() }
            23 -> { params.x = (resources.displayMetrics.widthPixels - params.width) / 2; params.y = resources.displayMetrics.heightPixels / 2; updatePosition() }
            24 -> { params.y = resources.displayMetrics.heightPixels - params.height - 80; updatePosition() }
            25 -> { followMode = !followMode; bubble.text = if (followMode) "跟随模式已开启（演示）" else "跟随模式已关闭"; showBubble(); return }
            26 -> { image.animate().translationXBy(70f).setDuration(600).withEndAction { image.animate().translationX(0f).setDuration(500).start() }.start() }
            27 -> { image.animate().cancel(); image.translationX = 0f }
            28 -> { bubble.text = "我会保持在其他应用上方显示。"; showBubble(); return }
            29 -> { toggleMenu(); return }
            30 -> { bubble.text = response; showBubble(); return }
            31 -> { bubble.text = "你已经点我 ${tapCount} 次啦！"; showBubble(); return }
            13 -> bounce()
            14 -> { image.animate().rotationBy(360f).setDuration(700).start() }
            4 -> { image.animate().rotationBy(12f).setDuration(180).withEndAction { image.animate().rotationBy(-24f).setDuration(180).withEndAction { image.animate().rotationBy(12f).setDuration(180).start() }.start() }.start() }
            5 -> { idleMode = false; image.alpha = 0.7f }
            6 -> { idleMode = true; image.alpha = alphaValue }
            7 -> { image.animate().scaleX(0.92f).scaleY(0.92f).setDuration(500).withEndAction { image.animate().scaleX(1f).scaleY(1f).setDuration(500).start() }.start() }
        }
        bubble.text = if (index == 31) "你已经点我 ${tapCount} 次啦！" else response
        showBubble()
    }

    private fun resize(newSize: Int) {
        petSize = newSize.coerceIn(100, 420)
        prefs.edit().putInt("size", petSize).apply()
        val density = resources.displayMetrics.density
        val dpSize = (petSize * density).toInt()
        val stage = root.getChildAt(1) as LinearLayout
        stage.getChildAt(0).layoutParams = LinearLayout.LayoutParams(dpSize, (dpSize * 1.45f).toInt())
        params.width = dpSize + (55 * density).toInt()
        params.height = (dpSize * 1.45f).toInt() + (70 * density).toInt()
        try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
        bubble.text = "尺寸：${petSize}px"
        showBubble()
    }

    private fun updatePosition() {
        try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
        prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
        if (menuShown) repositionMenu()
    }

    private fun showBubble() {
        bubble.visibility = View.VISIBLE
        bubble.postDelayed({ bubble.visibility = View.GONE }, 2400)
    }

    private fun bounce() {
        image.animate().cancel()
        image.scaleX = 1f; image.scaleY = 1f
        image.animate().scaleX(1.08f).scaleY(0.94f).setDuration(130)
            .withEndAction { image.animate().scaleX(0.96f).scaleY(1.06f).setDuration(140)
                .withEndAction { image.animate().scaleX(1f).scaleY(1f).setDuration(130).start() }.start() }.start()
    }

    private fun startIdleAnimation() {
        image.animate().cancel()
        image.animate().scaleX(1.015f).scaleY(1.015f).setDuration(1300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                if (idleMode) image.animate().scaleX(1f).scaleY(1f).setDuration(1300)
                    .setInterpolator(AccelerateDecelerateInterpolator()).withEndAction { startIdleAnimation() }.start()
            }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { if (::root.isInitialized) wm.removeView(root) } catch (_: Exception) {}
        try { if (::menuPanel.isInitialized) wm.removeView(menuPanel) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
